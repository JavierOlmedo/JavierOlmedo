; very simple script

Exit
