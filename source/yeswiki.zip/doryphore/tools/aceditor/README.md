# Aceditor Extension

Allows to have a nerdy editor in YesWiki's page edition mode.

## Usefull shortcuts

see <https://github.com/ajaxorg/ace/wiki/Default-Keyboard-Shortcuts>
