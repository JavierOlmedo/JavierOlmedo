<?php

/*vim=> set expandtab tabstop=4 shiftwidth=4=> */
// +------------------------------------------------------------------------------------------------------+
// | PHP version 5                                                                                        |
// +------------------------------------------------------------------------------------------------------+
// | Copyright (C) 2012 Outils-Réseaux (accueil@outils-reseaux.org)                                       |
// +------------------------------------------------------------------------------------------------------+
// | This library is free software; you can redistribute it and/or                                        |
// | modify it under the terms of the GNU Lesser General Public                                           |
// | License as published by the Free Software Foundation; either                                         |
// | version 2.1 of the License, or (at your option) any later version.                                   |
// |                                                                                                      |
// | This library is distributed in the hope that it will be useful,                                      |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of                                       |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU                                    |
// | Lesser General Public License for more details.                                                      |
// |                                                                                                      |
// | You should have received a copy of the GNU Lesser General Public                                     |
// | License along with this library; if not, write to the Free Software                                  |
// | Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA                            |
// +------------------------------------------------------------------------------------------------------+
//
/**
 * French translation for ACeditor extension.
 *
 *@author        Florian Schmitt <florian@outils-reseaux.org>
 *@copyright     2014 Outils-Réseaux
 */
$GLOBALS['translations'] = array_merge($GLOBALS['translations'], array(
    'ACEDITOR_SAVE' => 'Sauver',
    'ACEDITOR_FORMAT' => 'Format',
    'ACEDITOR_TITLE1' => 'Titre 1',
    'ACEDITOR_TITLE2' => 'Titre 2',
    'ACEDITOR_TITLE3' => 'Titre 3',
    'ACEDITOR_TITLE4' => 'Titre 4',
    'ACEDITOR_TITLE5' => 'Titre 5',
    'ACEDITOR_BIGGER_TEXT' => 'Texte agrandi',
    'ACEDITOR_HIGHLIGHT_TEXT' => 'Texte mis en valeur',
    'ACEDITOR_SOURCE_CODE' => 'Code source',
    'ACEDITOR_BOLD_TEXT' => 'Passe le texte s&eacute;lectionn&eacute; en gras  ( Ctrl-b )',
    'ACEDITOR_ITALIC_TEXT' => 'Passe le texte s&eacute;lectionn&eacute; en italique ( Ctrl-i )',
    'ACEDITOR_UNDERLINE_TEXT' => 'Souligne le texte s&eacute;lectionn&eacute; ( Ctrl-u )',
    'ACEDITOR_STRIKE_TEXT' => 'Barre le texte s&eacute;lectionn&eacute; ( Ctrl-y )',
    'ACEDITOR_LINE' => 'Ins&egrave;re une ligne horizontale',
    'ACEDITOR_LINK' => 'Lien',
    'ACEDITOR_LIST' => 'Liste à puce',
    'ACEDITOR_LINK_PROMPT' => 'Entrez l\'adresse URL',
    'ACEDITOR_LINK_TITLE'              => 'Ajoute un lien au texte s&eacute;lectionn&eacute;',
    'ACEDITOR_LINK_ADD_INTERNAL'       => 'Ajouter une page interne au YesWiki',
    'ACEDITOR_LINK_ADD_EXTERNAL'       => 'Ajouter une URL (lien externe)',
    'ACEDITOR_LINK_PAGE_NAME'          => 'Nom de la page YesWiki',
    'ACEDITOR_LINK_HINT_NEW_PAGE_NAME' => 'Si vous rentrez une page non-existante, elle sera créée.',
    'ACEDITOR_LINK_EXTERNAL'           => 'Lien externe',
    'ACEDITOR_LINK_TEXT'               => 'Texte du lien',
    'ACEDITOR_LINK_OPEN_IN_CURRENT_TAB'=> 'Le lien s\'ouvre dans l\'onglet courant',
    'ACEDITOR_LINK_OPEN_IN_NEW_TAB'    => 'Le lien s\'ouvre dans un nouvel onglet',
    'ACEDITOR_LINK_OPEN_IN_MODAL'      => 'Le lien s\'ouvre dans une fenêtre modale',
    'ACEDITOR_LINK_CANCEL'             => 'Annuler',
    'ACEDITOR_LINK_INSERT'             => 'Insérer',
    'ACEDITOR_HELP' => 'Aide mémoire',
    'ACEDITOR_ACTIONS' => "Composants",
    'ACEDITOR_ACTIONS_EDIT_CURRENT' => "Éditer le composant sélectionné",
    'ACEDITOR_COMMENT' => 'Commentaires',

    'ACTION_BUILDER_CHOOSE_FORM' => 'Choisissez un Formulaire',
    'ACTION_BUILDER_CHOOSE_TEMPLATE' => 'Sous quelle forme voulez-vous afficher les données?',
    'ACTION_BUILDER_CHOOSE_ACTION' => 'Choisissez une action',
    'ACTION_BUILDER_WIKI_CODE_TITLE' => "Code à include dans la page",
    'ACTION_BUILDER_PARAMETERS' => 'Paramètres',
    'ACTION_BUILDER_COPY' => 'Copier',
    'ACTION_BUILDER_SEVERAL_FORMS_HINT' => 'Nb. : Il est possible d\'afficher plusieurs bases de donn&eacute;es d\'un coup en entrant leur id s&eacute;par&eacute; par une virgule [<a href="https://yeswiki.net/?ActionBazarliste">acc&eacute;der &agrave; la documentation</a>].',
    'ACTION_BUILDER_ADVANCED_PARAMETERS' => 'Paramètres Avancés',
    'ACTION_BUILDER_PREVIEW'             => 'Aperçu (non cliquable)',
    'ACTION_BUILDER_ONLINEDOC'           => 'Documentation en ligne',
    'ACTION_BUILDER_UPDATE_CODE'         => 'Mettre à jour le code',
    'ACTION_BUILDER_INSERT_CODE'         => 'Insérer dans la page',

    // for edit config
    'EDIT_CONFIG_HINT_ACTIONBUILDER_TEXTAREA_NAME' => 'Nom du champ bazar texte long pour lequel les composants sont visibles',
    'EDIT_CONFIG_GROUP_ACEDITOR' => 'Barre d\'édition pour les pages et les champs texte',
));
