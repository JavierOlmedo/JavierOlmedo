// ext/Number/Color/slider
export default {
  props: [ 'value', 'config' ],
  template: `<input type="hidden" :value="value" />`
}
