<?php

/**
* @Annotation
*/
final class Field
{
    /** @array */
    public $keywords;
}
