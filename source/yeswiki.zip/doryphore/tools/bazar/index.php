<?php
// Administration


// Verification de securite
if (!defined("TOOLS_MANAGER")) {
    die("acc&egrave;s direct interdit");
}

$buffer->str(
    '
Le plugin "Bazar" vous permet de gerer un systeme de fiches (saisie, modification, RSS, recherche, consultation, administration).
'
);
