<?php
$GLOBALS['translations'] = array_merge($GLOBALS['translations'], array(
    'HELLOWORLD_MY_MESSAGE' => 'My message',
    'HELLOWORD_NO_MSG_PARAM' => 'No \'message\' parameter defined in the {{greeting ...}} action',
    'HELLOWORD_CALLBACK_MSG' => '(the action argument is changed in the before callback)',
    'HELLOWORLD_CONFIG' => 'Test config',
    'HELLOWORLD_URL_SHOW_XML' => 'See XML Info Of Current Page',
    'HELLOWORLD_URL_SHOW_TAG' => 'Show %{tag}',
    'HELLOWORLD_URL_EDIT_TAG' => 'Edit %{tag}',
    'HELLOWORLD_URL_EDIT_WITH_PARAMS' => 'Edit current page with params',
    'HELLOWORLD_PAGE_NOT_ACCESSIBLE' => 'Page non accessible',
));
